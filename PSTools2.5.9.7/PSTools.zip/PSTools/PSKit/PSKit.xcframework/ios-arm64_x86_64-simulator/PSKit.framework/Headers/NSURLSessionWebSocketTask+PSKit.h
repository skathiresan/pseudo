//
//  Copyright © 2022 Product Science. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

API_AVAILABLE(ios(13.0))
/// Info collected and returned by the hooks on `NSURLSessionWebSocketTask`'s `send/receiveMessage...` methods.
@interface PSKWebSocketMessageInfo: NSObject

@property (nonatomic, readonly) NSURLSessionTask *task;
@property (nonatomic, readonly, nullable) NSData *messageData;
@property (nonatomic, readonly, nullable) NSString *messageString;
@property (nonatomic, readonly, nullable) NSError *error;
@property (nonatomic, readonly) NSString *sessionID;
@property (nonatomic, readonly) NSString *taskUUID;
@property (nonatomic, readonly) NSString *className;
@property (nonatomic, readonly) NSString *selectorName;

@end

API_AVAILABLE(ios(13.0))
@interface NSURLSessionWebSocketTask (PSKit)

/// Hook entry/exit of `-[NSURLSessionWebSocketTask sendMessage:completionHandler:]` method.
+ (void)psk_addSendMessageHooksBefore:(void (^)(PSKWebSocketMessageInfo *))before
                                after:(void (^)(PSKWebSocketMessageInfo *))after;

/// Hook entry/exit of completion handler for `-[NSURLSessionWebSocketTask receiveMessageWithCompletionHandler:]` method.
+ (void)psk_addReceiveMessageHooksBefore:(void (^)(PSKWebSocketMessageInfo *))before
                                   after:(void (^)(PSKWebSocketMessageInfo *))after;

/// Un-hook all hooked `NSURLSessionWebSocketTask` methods.
+ (void)psk_removeWebSocketHooks;

@end

NS_ASSUME_NONNULL_END
