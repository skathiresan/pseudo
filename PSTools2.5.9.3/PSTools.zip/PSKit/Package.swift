// swift-tools-version:5.3
import PackageDescription

// To add in Package.swift
// dependencies.append(contentsOf: [
//     .package(path: "../PSKit"),
// ])

let package = Package(
    name: "PSKit",
    products: [
        .library(
            name: "PSKit",
            targets: ["PSKit"]),
    ],
    targets: [
        .binaryTarget(name: "PSKit", path: "PSKit.xcframework")
    ]
)