//
//  Copyright © 2022 Product Science. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/// Info collected and returned by the hooks on `NSURLSession`'s `...TaskWith...:completionHandler:` methods.
@interface PSKSessionTaskCompletionInfo: NSObject

@property (nonatomic, readonly) NSURLSessionTask *task;
@property (nonatomic, readonly, nullable) NSURLSessionTaskMetrics *metrics;
@property (nonatomic, readonly) NSString *taskUUID;
@property (nonatomic, readonly) NSString *selectorName;

@end

@interface NSURLSession (PSKit)

/// Hook entry/exit of `-[NSURLSession initWithConfiguration:delegate:delegateQueue:delegateDispatchQueue:]`.
///
/// We use these hooks as our cue to swizzle relevant protocol methods on the `delegate`.
+ (void)psk_addInitHooksBefore:(void (^)(_Nullable id<NSURLSessionDelegate>))before
                         after:(void (^)(_Nullable id<NSURLSessionDelegate>))after;

/// Hook entry/exit of completion handler for `-[NSURLSession dataTaskWith...:completionHandler:]` methods.
+ (void)psk_addDataTaskCompletionHooksBefore:(void (^)(PSKSessionTaskCompletionInfo *))before
                                       after:(void (^)(PSKSessionTaskCompletionInfo *))after;

/// Hook entry/exit of completion handler for `-[NSURLSession uploadTaskWithRequest:...:completionHandler:]` methods.
+ (void)psk_addUploadTaskCompletionHooksBefore:(void (^)(PSKSessionTaskCompletionInfo *))before
                                         after:(void (^)(PSKSessionTaskCompletionInfo *))after;

/// Hook entry/exit of completion handler for `-[NSURLSession downloadTaskWith...:completionHandler:]` methods.
+ (void)psk_addDownloadTaskCompletionHooksBefore:(void (^)(PSKSessionTaskCompletionInfo *))before
                                           after:(void (^)(PSKSessionTaskCompletionInfo *))after;

/// Un-hook all hooked `NSURLSession` methods.
///
/// Do not un-hook init - we need to keep track of session delegates when not recording.
+ (void)psk_removeAllButInitHooks;

@end

NS_ASSUME_NONNULL_END
